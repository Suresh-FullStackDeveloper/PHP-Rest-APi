Luracast Restler Framework
==========================

Restler is a simple and effective multi-format Web API Server written in PHP.

This repository contains just the framework files for installing the framework core using composer require statements.

For more information, usage examples, pull requests, and issues go to the [Main Repository](https://github.com/Luracast/Restler)