<?php
echo $basePath;