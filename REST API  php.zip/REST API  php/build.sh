/usr/local/Cellar/php@7.4/7.4.19_1/bin/php build/examples.php
