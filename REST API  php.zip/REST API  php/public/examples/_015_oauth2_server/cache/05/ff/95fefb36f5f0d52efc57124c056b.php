<?php

/* oauth2/github.twig */
class __TwigTemplate_05ff95fefb36f5f0d52efc57124c056b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<a href=\"https://github.com/Luracast/Restler\"><img style=\"position: absolute; top: 0; right: 0; border: 0;z-index:100000\" src=\"https://s3.amazonaws.com/github/ribbons/forkme_right_red_aa0000.png\" alt=\"Fork me on GitHub\"></a>";
    }

    public function getTemplateName()
    {
        return "oauth2/github.twig";
    }

    public function getDebugInfo()
    {
        return array (  26 => 5,  21 => 2,  19 => 1,);
    }
}
